vad_directed_by_noise_classification.m

This code is an implementation of VAD algorithm proposed in:
"voice activity detection directed by noise classification"


the folder is also contained the following

* different noise models for svm
* different sub_functions.
* three speech signal from TIMIT dataset and their vad labels


Note that you need to download noise dataset from

http://spib.rice.edu/spib/select.

and libsvm toolbox from

http://www.csie.ntu.edu.tw/~cjlin/libsvm/



Jamal Saeedi
Amirkabir University of Technology
Electrical Engineering Department